package Task2;

public class Town extends Venue {

    public Town(String name) {
        super(name);
    }
}